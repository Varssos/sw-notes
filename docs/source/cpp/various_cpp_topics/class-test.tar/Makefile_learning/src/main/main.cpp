#include <iostream>
#include "connection.hpp"
#include "main.hpp"




int main()
{

    std::shared_ptr<Device> obj;

    obj = std::make_shared<ModbusRTUDevice>();

    // obj->Connect();

    ModbusTCPDevice aModbusTCPDevice;

    // aModbusTCPDevice.Connect();

    test(obj);
    
    std::cout << "Jado " << std::endl;

    return 0;
}


void test ( std::shared_ptr<Device> &aDevice )
{
    aDevice->Connect();
}