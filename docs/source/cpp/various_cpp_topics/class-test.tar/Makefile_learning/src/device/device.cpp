#include <iostream>
#include "device.hpp"

Device::Device(/* args */)
{
}

Device::~Device()
{
}

void Device::Connect()
{
    std::cout << "Device::Connect" << std::endl;
}


ModbusTCPDevice::ModbusTCPDevice(/* args */)
{
}

ModbusTCPDevice::~ModbusTCPDevice()
{
}

void ModbusTCPDevice::Connect()
{
    std::cout << "ModbusTCPDevice::Connect" << std::endl;
}



ModbusRTUDevice::ModbusRTUDevice(/* args */)
{
}

ModbusRTUDevice::~ModbusRTUDevice()
{
}

void ModbusRTUDevice::Connect()
{
    std::cout << "ModbusRTUDevice::Connect" << std::endl;
}

