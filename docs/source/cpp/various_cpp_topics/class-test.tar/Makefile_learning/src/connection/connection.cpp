#include "connection.hpp"

IConnection::IConnection(/* args */)
{
}

IConnection::~IConnection()
{
}