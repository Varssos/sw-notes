#pragma once
#include "connection.hpp"

class Device : public IConnection
{
private:
    /* data */
public:
    Device(/* args */);
    ~Device();
    void Connect() override;
    
};

class ModbusTCPDevice : public Device
{
private:

public:
    ModbusTCPDevice();
    ~ModbusTCPDevice();
    void Connect() override;
};

class ModbusRTUDevice : public Device
{
private:

public:
    ModbusRTUDevice();
    ~ModbusRTUDevice();
    void Connect() override;
};
