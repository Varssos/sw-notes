#pragma once

#include "device.hpp"
#include <memory>

void test ( std::shared_ptr<Device> &aDevice);