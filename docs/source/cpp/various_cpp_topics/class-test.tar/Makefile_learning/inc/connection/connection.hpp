#pragma once

class IConnection
{
private:
    /* data */
public:
    IConnection(/* args */);
    ~IConnection();
    virtual void Connect() = 0;
};


