#include "app/app.hpp"
#include "device/device.hpp"
#include "config/config.hpp"

int main()
{
    ModbusDevice{};

    return 0;
}