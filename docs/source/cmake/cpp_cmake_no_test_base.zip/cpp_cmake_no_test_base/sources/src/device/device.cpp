#include "device/device.hpp"

Device::Device()
{
    std::cout << "Device\n";
}

Device::~Device()
{
    std::cout << "~Device\n";
}


ModbusDevice::ModbusDevice()
{
    std::cout << "ModbusDevice\n";
}

ModbusDevice::~ModbusDevice()
{
    std::cout << "~ModbusDevice\n";
}

