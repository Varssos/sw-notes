#pragma once
#include <iostream>

class IDevice
{
  public:
    IDevice(){};
    virtual ~IDevice(){};
};

class Device : public IDevice
{
  public:
    Device();
    virtual ~Device();
};

class ModbusDevice : public Device
{
  public:
    ModbusDevice();
    virtual ~ModbusDevice();
};
