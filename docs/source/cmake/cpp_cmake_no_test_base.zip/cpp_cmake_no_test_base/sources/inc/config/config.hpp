#pragma once
#include <iostream>

class Config
{
  public:
    Config();
    virtual ~Config();
};
